"""Deterministic CONTRACT evidence: signature + raises + guards + return shape.

The CONTRACT pillar of GT Context Philosophy (CLAUDE.md): the interface facts an
agent must preserve when editing a function — the valid value-domains (the full
typed ``signature``, e.g. ``split_by: Literal["word","sentence","page","line"]``),
the exceptions it raises, the preconditions/early-returns (guards), and the return
shape. These are read from the ``properties`` table + ``nodes`` — facts the parser
already extracted, that the first-turn brief currently throws away.

Always-available: a function's OWN contract needs NO graph edges (it is node-local),
so it fires even on isolated functions where the agent is most blind. The 1-hop
CALLEE contract (what the functions this one calls can raise — e.g. a wrapped
``os.utime`` raising ``OSError``) is gated on VERIFIED edges only, so a name_match
guess never launders as "this callee raises X".

Correct-or-quiet: emit only what the parser actually extracted; abstain (empty
string) when nothing is known rather than guess. Tier A kinds (exception_type,
guard_clause, return_shape) are present in every indexed db; Tier B kinds
(boundary_condition, conditional_return, exception_flow) appear when the repo was
indexed by the current binary.

Research: The Distracting Effect (arXiv:2505.06914, 2025) — plausible-but-wrong
context drops accuracy 6-11pp, so never render an unverified callee edge as a fact.
Lost in the Middle (NeurIPS 2024) — signature first (primacy). LLM-free, $0, pure SQL.
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass, replace

from groundtruth.pretask.curation_map import (
    _DETERMINISTIC_METHODS,
    _has_columns,
    _is_cross_language_pair,
    _neighbors,
    _node_ids,
    _nodes_have_language,
    _open_ro,
    verified_caller_count,
)
from groundtruth.runtime.sanitizer import (
    clip_balanced,
    valid_exception_spec,
    valid_guard_clause,
    valid_return_shape,
)


# Per-kind SEMANTIC validators (C1b — B3 semantic-nonsense contract). clip_balanced
# is STRUCTURAL only: it passes ``raise,exc_info[1].with_traceback`` (brackets
# balanced) and an empty guard. The indexer occasionally stores a parsed statement
# fragment as a "raises"/"guard"/"return" value (e.g. a re-raise of an exc_info
# tuple mined as an exception_type), so a mined value must clear a per-kind shape
# check before it can render. Correct-or-quiet: a value that is not a well-formed
# exception NAME / guard expression / return shape is DROPPED, never rendered.
# Research: The Distracting Effect (arXiv:2505.06914, 2025) — structurally-balanced-
# but-wrong context degrades agents, so suppress, don't render. Language-agnostic
# (the validators reason about identifiers/brackets, not Python AST).
def _valid_data_flow(v: str) -> bool:
    """A data_flow value is ``<param> -> <use> | <use>``. Require the arrow to have
    survived clip_balanced (a value reduced to just the param name or to a dangling
    fragment carries no provenance) and a non-empty right-hand side. Correct-or-quiet.
    """
    if " -> " not in v:
        return False
    rhs = v.split(" -> ", 1)[1].strip()
    return bool(rhs)


_CONTRACT_VALUE_VALIDATORS = {
    "exception_type": valid_exception_spec,
    "guard_clause": valid_guard_clause,
    "return_shape": valid_return_shape,
    "data_flow": _valid_data_flow,
}

# Tier A — populated in every indexed db (verified empirically 2026-05-29).
_TIER_A_KINDS = ("exception_type", "guard_clause", "return_shape")
# Tier B — richer kinds the current binary extracts (older task dbs lack them).
# data_flow = per-parameter forward slice (def-use): where each input VALUE flows
# inside the body (the dimension the call graph lacks — the off-by-one "where is
# count checked vs incremented" question). Heuristic (indexer confidence 0.8), so
# it renders but is gated by the per-kind value validator below (correct-or-quiet).
_TIER_B_KINDS = ("boundary_condition", "conditional_return", "exception_flow", "data_flow")
_CONTRACT_KINDS = _TIER_A_KINDS + _TIER_B_KINDS

# Cap each kind so the rendered block stays inside the token budget.
_MAX_PER_KIND = 3
# 1-hop for callee contracts (RepoGraph ICLR 2025: 1-hop > 2-hop).
_MAX_CALLEES = 3


@dataclass(frozen=True)
class ContractEvidence:
    """The deterministic contract of a single function."""

    file: str
    function: str
    signature: str = ""
    return_type: str = ""
    raises: tuple[str, ...] = ()  # exception_type values
    guards: tuple[str, ...] = ()  # guard_clause values
    return_shape: str = ""  # most-common return_shape
    boundaries: tuple[str, ...] = ()  # boundary_condition (Tier B)
    conditionals: tuple[str, ...] = ()  # conditional_return (Tier B)
    exc_flows: tuple[str, ...] = ()  # exception_flow (Tier B)
    flows: tuple[str, ...] = ()  # data_flow: per-param forward slice (Tier B)
    # G17 (gt_new §6:73) — SCOPE/COMPLETENESS blast facts: the promoted READS/WRITES
    # of the EDIT-TARGET ("writes to <field>; <N> verified readers"). Node-local
    # (keyed to the edit-target's OWN outgoing WRITES), confidence-gated >=0.5,
    # DISPLAY-ONLY. Never an edit-target's score/degree/reach input (I2). Only the
    # edit-target carries these, never a callee.
    blast: tuple[str, ...] = ()
    is_callee: bool = False  # True when this is a verified 1-hop callee's contract

    @property
    def has_signal(self) -> bool:
        return bool(
            self.raises
            or self.guards
            or self.return_shape
            or self.boundaries
            or self.conditionals
            or self.exc_flows
            or self.flows
            or self.blast
            # A callee with a known signature IS signal — the deciding interface
            # fact the edit-target must call correctly (the set_parse(self, key,
            # string: str) the agent otherwise greps for). The is_callee guard was
            # dropping exactly that. (Task #48, 2026-05-30)
            or self.signature
        )


# Pyright/LSP hover markers that leak into nodes.signature during the LSP resolve
# pass. Pyright hover `contents` is markdown — ```python\n(method) def f(...) -> T\n```
# — and the raw markdown was rendering verbatim into the brief (defect D-2, observed
# 8/10 briefs on the 2026-06-04 ramp). Strip it to the bare signature line.
_HOVER_KIND_RE = re.compile(
    r"^\((?:method|function|property|variable|class|parameter|field|constant|module|overload)\)\s*"
)

# Max chars for a rendered signature in the brief. A SIGNATURE contract is the typed
# param list + return — never prose. ~200 chars holds a wide multi-arg typed header;
# anything longer is a docstring/annotation body the compact rule (gt_new App D,
# CLAUDE.md Core Product Contract "compact, high-precision") wants stripped.
_MAX_RENDERED_SIG = 200

# Triple-quoted docstrings embedded in a signature: ``Annotated[T, Doc("""..."""])``
# (FastAPI/pydantic Doc()/Field(description=)), or any inline ``"""..."""`` /
# ``'''...'''`` prose the parser captured verbatim. Non-greedy, DOTALL so it spans the
# (whitespace-flattened) multi-line body. Both quote styles; the store caps signatures
# at 1000 chars so the closing delimiter is often missing — a second open-ended pass
# collapses a truncated/unterminated opener.
_TRIPLE_DOC_RE = re.compile(r'("""|\'\'\')(?:(?!\1).)*?\1', re.DOTALL)
_TRIPLE_DOC_OPEN_RE = re.compile(r'("""|\'\'\').*$', re.DOTALL)


def _strip_signature_prose(sig: str) -> str:
    """Collapse embedded docstrings out of a signature and cap its length.

    Language-agnostic, render-time (no reindex). A *signature* contract is the typed
    params + return type — NOT the ``Annotated[T, Doc(\"\"\"...long prose...\"\"\")]``
    docstrings FastAPI/pydantic attach to each param (~1 KB each for
    ``post``/``put``/``include_router``), Javadoc, or Rust doc-comments the parser
    captured verbatim. This:

    1. Replaces every triple-quoted ``\"\"\"...\"\"\"`` / ``'''...'''`` body inside the
       signature with ``...`` — so ``Doc(\"\"\"long\"\"\")`` collapses to ``Doc(...)``
       (the typed ``Annotated[str, Doc(...)]`` survives; the prose does not).
    2. Drops a trailing *unterminated* triple-quote (the store truncates at 1000 chars,
       so the closing delimiter is frequently absent).
    3. Flattens whitespace runs (the parser preserved newlines/indentation).
    4. Caps the result at ``_MAX_RENDERED_SIG`` chars with a trailing ``…``.

    Short, normal signatures (``def openapi(self) -> dict[str, Any]:``) pass through
    UNCHANGED (the fast path returns before any sub). General: any ``Annotated``+``Doc``/
    ``Field`` codebase or long-docstring-in-signature, any language with triple-quoted
    prose — not FastAPI-keyed.
    """
    if not sig:
        return sig
    # Fast path: a normal short signature with no embedded prose is byte-identical.
    if '"""' not in sig and "'''" not in sig and len(sig) <= _MAX_RENDERED_SIG:
        return sig
    out = _TRIPLE_DOC_RE.sub("...", sig)
    out = _TRIPLE_DOC_OPEN_RE.sub("...", out)
    out = re.sub(r"\s+", " ", out).strip()
    if len(out) > _MAX_RENDERED_SIG:
        out = out[: _MAX_RENDERED_SIG - 1].rstrip() + "…"
    return out


def _sanitize_signature(sig: str) -> str:
    """Strip leaked LSP/Pyright hover markdown AND embedded docstring prose, then cap.

    Reduces ```python\\n(method) def wait(self, ...) -> None\\n``` to ``def wait(self,
    ...) -> None``, and collapses ``Annotated[str, Doc(\"\"\"...prose...\"\"\")]`` to
    ``Annotated[str, Doc(...)]`` capped at ``_MAX_RENDERED_SIG`` chars. No-op on
    already-clean short ``def ...`` / ``name(...)`` signatures (fast path).
    Correct-or-quiet: a structurally-balanced-but-wrong fence / a multi-KB docstring is
    exactly the "plausible-but-wrong / distracting context" that drops agent accuracy
    6-11pp (The Distracting Effect, arXiv:2505.06914, 2025) — removed, not rendered.
    Language-agnostic (operates on fences/markers/quotes, not Python AST).
    """
    if not sig:
        return sig
    s = sig.strip()
    if "```" in s or s.startswith("("):
        s = s.replace("```python", " ").replace("```", " ")
        cleaned: list[str] = []
        for ln in s.splitlines():
            ln = _HOVER_KIND_RE.sub("", ln.strip()).strip()
            if ln:
                cleaned.append(ln)
        if not cleaned:
            return ""
        # Prefer the first line that looks like a signature (has an arg list).
        s = next((ln for ln in cleaned if "(" in ln), cleaned[0])
    # Strip embedded docstring prose + cap length (D2). Fast-path no-op on a short,
    # prose-free signature, so existing clean signatures stay byte-identical.
    return _strip_signature_prose(s)


def _node_meta(conn: sqlite3.Connection, node_ids: list[int]) -> tuple[str, str]:
    """Return (signature, return_type) for the lowest-line node in ``node_ids``."""
    if not node_ids:
        return ("", "")
    placeholders = ",".join("?" for _ in node_ids)
    try:
        row = conn.execute(
            f"SELECT signature, return_type FROM nodes WHERE id IN ({placeholders}) "
            f"ORDER BY start_line LIMIT 1",
            node_ids,
        ).fetchone()
    except sqlite3.Error:
        return ("", "")
    if not row:
        return ("", "")
    return (_sanitize_signature(row[0] or ""), row[1] or "")


# B-22: the FACT trust tiers a property may carry (mirrors the edge tiers). A property
# whose (non-empty) trust_tier is outside this set — SPECULATIVE — is not a contract
# FACT (correct-or-quiet). An EMPTY tier is legacy (the column absent, or a row a current
# binary left unstamped) and is gated on confidence alone, never dropped for the tier.
_FACT_TRUST_TIERS: frozenset[str] = frozenset({"CERTIFIED", "CANDIDATE"})


def _property_columns(conn: sqlite3.Connection) -> set[str]:
    """The column names of the ``properties`` table (empty set on any error)."""
    try:
        return {r[1] for r in conn.execute("PRAGMA table_info(properties)").fetchall()}
    except sqlite3.Error:
        return set()


def _gated_prop_rows(
    conn: sqlite3.Connection, node_ids: list[int]
) -> list[tuple[str, str, int, float, int, int, str, str, str, str, str, str]]:
    """The confidence+trust_tier-gated, value-validated CONTRACT property rows.

    Returns ``[(kind, value, line, confidence, start_line, end_line, trust_tier,
    extractor, evidence_method, verification_status, property_id, source_revision), ...]``
    in source (line) order — the ONE gated read shared by :func:`_read_props` (values
    only) and :func:`read_property_facts` (provenance-carrying).

    B-22 provenance + back-compat: the read PROBES the ``properties`` columns and SELECTs
    the per-fact provenance (``property_id``/span/tier/extractor/…) only when present, so
    a legacy properties table (``node_id,kind,value,line,confidence``) reads WITHOUT error
    (absent columns default: span -> ``line``; the rest -> ``''``). The ``confidence``
    column is REQUIRED (B-25): a schema lacking it cannot verify mining confidence, so the
    read returns ``[]`` (correct-or-quiet) rather than laundering unconfidence-able values.

    GATES (both correct-or-quiet): (1) ``confidence >= 0.5`` (the fact floor, in SQL);
    (2) a NON-EMPTY ``trust_tier`` must be a FACT tier (:data:`_FACT_TRUST_TIERS`) — an
    empty tier (legacy) is gated on confidence alone. Then ``clip_balanced`` repairs a
    blind-byte-capped value and the per-kind semantic validator drops a parsed-statement
    fragment laundering as a contract fact.
    """
    if not node_ids:
        return []
    cols = _property_columns(conn)
    # B-25: cannot verify mining confidence without the column -> correct-or-quiet.
    if "confidence" not in cols:
        return []
    placeholders = ",".join("?" for _ in node_ids)
    kind_ph = ",".join("?" for _ in _CONTRACT_KINDS)

    def _col_or(name: str, default_expr: str) -> str:
        """The column ``name`` when the properties table has it, else ``default_expr``
        (a literal SQL expression) — so an old db without the B-22 provenance columns
        reads with a sensible default instead of ``no such column`` (COALESCE for legacy)."""
        return name if name in cols else default_expr

    e_line = "COALESCE(line,0)"
    # Graph-F5 (B-25 fail-CLOSED): a NULL confidence is UNCONFIDENCE-ABLE, not maximal.
    # COALESCE(...,0.0) fails it below the 0.5 gate (parity with the gateway's
    # _fact_callers); the prior ...,1.0 floated a NULL to max authority (fail-OPEN).
    e_conf = "COALESCE(confidence,0.0)"
    e_start = "COALESCE(" + _col_or("start_line", "line") + ", line, 0)"
    e_end = "COALESCE(" + _col_or("end_line", "line") + ", line, 0)"
    e_tier = "COALESCE(" + _col_or("trust_tier", "''") + ", '')"
    e_extr = "COALESCE(" + _col_or("extractor", "''") + ", '')"
    e_evm = "COALESCE(" + _col_or("evidence_method", "''") + ", '')"
    e_vst = "COALESCE(" + _col_or("verification_status", "''") + ", '')"
    e_pid = "COALESCE(" + _col_or("property_id", "''") + ", '')"
    e_srev = "COALESCE(" + _col_or("source_revision", "''") + ", '')"
    sql = (
        "SELECT kind, value, "
        + e_line
        + ", "
        + e_conf
        + ", "
        + e_start
        + ", "
        + e_end
        + ", "
        + e_tier
        + ", "
        + e_extr
        + ", "
        + e_evm
        + ", "
        + e_vst
        + ", "
        + e_pid
        + ", "
        + e_srev
        + " "
        "FROM properties "
        "WHERE node_id IN (" + placeholders + ") AND kind IN (" + kind_ph + ") "
        "AND " + e_conf + " >= 0.5 ORDER BY line"
    )
    try:
        rows = conn.execute(sql, (*node_ids, *_CONTRACT_KINDS)).fetchall()
    except sqlite3.Error:
        return []
    out: list[tuple[str, str, int, float, int, int, str, str, str, str, str, str]] = []
    for (
        kind,
        value,
        line,
        conf,
        start_line,
        end_line,
        tier,
        extractor,
        ev_method,
        vstatus,
        prop_id,
        src_rev,
    ) in rows:
        if not value:
            continue
        # B-22 trust_tier gate (correct-or-quiet): a non-empty tier outside the FACT
        # tiers (SPECULATIVE) is not a contract fact; an empty tier gates on confidence.
        t = (str(tier) if tier is not None else "").strip().upper()
        if t and t not in _FACT_TRUST_TIERS:
            continue
        # Repair a value the indexer stored mid-expression (blind byte cap on an older
        # build) so the brief never emits an unterminated literal / dangling operator.
        v = clip_balanced(str(value).strip())
        if not v:
            continue
        # SEMANTIC gate (C1b): a mined value must be a well-formed instance of its kind,
        # else it is a parsed statement fragment laundering as a contract fact. Drop it.
        _validate = _CONTRACT_VALUE_VALIDATORS.get(kind)
        if _validate is not None and not _validate(v):
            continue
        out.append(
            (
                str(kind),
                v,
                int(line or 0),
                float(conf or 0.0),
                int(start_line or 0),
                int(end_line or 0),
                t,
                str(extractor or ""),
                str(ev_method or ""),
                str(vstatus or ""),
                str(prop_id or ""),
                str(src_rev or ""),
            )
        )
    return out


def _read_props(conn: sqlite3.Connection, node_ids: list[int]) -> dict[str, list[str]]:
    """Return {kind: [value, ...]} for contract kinds, deduped, capped per kind.

    Order within a kind preserved by line (the source order the agent will see). The
    gated read (confidence + trust_tier, back-compat column-probe) is shared with
    :func:`read_property_facts` via :func:`_gated_prop_rows`; this returns the value-only
    projection the existing consumers expect (shape unchanged — the property_id + span
    provenance rides the :func:`read_property_facts` surface).
    """
    if not node_ids:
        return {}
    out: dict[str, list[str]] = {}
    seen: dict[str, set[str]] = {}
    for row in _gated_prop_rows(conn, node_ids):
        kind, v = row[0], row[1]
        bucket = out.setdefault(kind, [])
        seenset = seen.setdefault(kind, set())
        if v in seenset or len(bucket) >= _MAX_PER_KIND:
            continue
        seenset.add(v)
        bucket.append(v)
    return out


@dataclass(frozen=True)
class PropertyFact:
    """One provenance-carrying contract property (B-22) — the fact value plus the
    per-fact identity + span + tier the receipt / dedup layer keys on.

    ``property_id`` is the stable content id (the dedup/receipt key; a 64-hex id on a
    current db, ``''`` on a legacy one); ``(start_line, end_line)`` is the fact's span.
    This is the surface the ``{kind: [values]}`` shape of :func:`_read_props` cannot
    carry — a distinct, back-compat return shape that DOES allow the provenance.
    """

    file: str
    function: str
    kind: str
    value: str
    line: int
    start_line: int
    end_line: int
    confidence: float
    trust_tier: str
    extractor: str
    evidence_method: str
    verification_status: str
    property_id: str
    source_revision: str


def read_property_facts(
    graph_db_path: str, file_path: str, func_names: list[str]
) -> list[PropertyFact]:
    """Provenance-carrying contract properties for ``(file_path, func_names)`` — the B-22
    receipt surface. SAME gate as :func:`_read_props` (confidence + trust_tier, back-compat
    column-probe), but each row CARRIES ``property_id`` (the dedup/receipt key), the
    ``(start_line, end_line)`` span, the trust tier, and the extractor/evidence/
    verification provenance — which the ``{kind: [values]}`` shape cannot.

    Deduped by ``property_id`` (or ``(kind, value)`` on a legacy db that has no
    property_id). Pure read; never raises; returns ``[]`` on a bad/missing db or a legacy
    schema without a ``confidence`` column. Generalized — any file/language indexed by
    gt-index.
    """
    if not func_names:
        return []
    conn = _open_ro(graph_db_path)
    if conn is None:
        return []
    try:
        facts: list[PropertyFact] = []
        seen: set[str] = set()
        for fname in func_names:
            if not fname:
                continue
            ids = _node_ids(conn, file_path, fname)
            if not ids:
                continue
            for (
                kind,
                value,
                line,
                conf,
                start_line,
                end_line,
                tier,
                extractor,
                ev_method,
                vstatus,
                prop_id,
                src_rev,
            ) in _gated_prop_rows(conn, ids):
                key = prop_id or (kind + "\x00" + value)
                if key in seen:
                    continue
                seen.add(key)
                facts.append(
                    PropertyFact(
                        file=file_path,
                        function=fname,
                        kind=kind,
                        value=value,
                        line=line,
                        start_line=start_line,
                        end_line=end_line,
                        confidence=conf,
                        trust_tier=tier,
                        extractor=extractor,
                        evidence_method=ev_method,
                        verification_status=vstatus,
                        property_id=prop_id,
                        source_revision=src_rev,
                    )
                )
        return facts
    finally:
        conn.close()


# G17 cap — keep the blast-fact note compact (one line of SCOPE context, not a dump).
_MAX_BLAST_FIELDS = 3
# Fact floor (I1/I3, B-26) — a promoted edge below 0.7 is not a FACT (the producer emits
# undeclared-field READS/WRITES at 0.6). Gate READS/WRITES on 0.7 so only verified edges
# render as "verified readers", never a 0.6 structural guess.
_BLAST_CONF_FLOOR = 0.7


def _blast_facts(
    conn: sqlite3.Connection,
    node_ids: list[int],
    *,
    has_conf: bool,
) -> tuple[str, ...]:
    """SCOPE/COMPLETENESS blast facts for the EDIT-TARGET (G17, gt_new §6:73).

    The promoted WRITES edges where the edit-target node is the SOURCE name the
    class FIELDS this function mutates (``metadata`` carries the field name; the
    edge target is the owning Class node). For each written field, count the
    VERIFIED readers — distinct READS sources pointing at the SAME owning class —
    so the agent sees the completeness fact "if I change how this field is set, N
    other methods read it." Rendered as a node-local SCOPE note, e.g.
    ``writes to _cache; 4 verified readers``.

    DISPLAY-ONLY, node-local-or-quiet (I2): this consumes promoted depth edges but
    NEVER feeds any rank / reach / degree / score term — the contract pillar has no
    score path (the RRF / total-score ranking surfaces live in other modules).
    Confidence-gated >= 0.7 (B-26) on a current binary; a legacy schema with no ``confidence``
    column is QUIET, not permissive (correct-or-quiet). ``()`` when no WRITES is promoted.
    Pure read; never raises. Generalized — any language the promote pass emits
    READS/WRITES for (Python/Go/JS/TS), no benchmark- or task-specific logic.
    """
    if not node_ids:
        return ()
    # B-26: without a `confidence` column we cannot apply the fact floor, so an
    # unconfidence-able edge would render as a "verified reader" (false authority).
    # Correct-or-quiet: emit nothing on a legacy schema rather than unverified facts.
    if not has_conf:
        return ()
    placeholders = ",".join("?" for _ in node_ids)
    # WRITES the edit-target performs: target_id = owning Class, metadata = field.
    # Graph-F6 (B-26 fail-CLOSED): COALESCE(...,0.0) so a NULL-confidence edge fails the
    # 0.7 fact floor instead of floating to 1.0 and rendering as a "verified" writer.
    w_conf = "AND COALESCE(e.confidence, 0.0) >= ?" if has_conf else ""
    w_params: list[object] = list(node_ids)
    if has_conf:
        w_params.append(_BLAST_CONF_FLOOR)
    try:
        writes = conn.execute(
            f"SELECT DISTINCT e.target_id, e.metadata FROM edges e "
            f"WHERE e.source_id IN ({placeholders}) AND e.type = 'WRITES' {w_conf}",
            w_params,
        ).fetchall()
    except sqlite3.Error:
        return ()
    if not writes:
        return ()
    out: list[str] = []
    seen_fields: set[str] = set()
    for owner_class_id, field in writes:
        field = (str(field) if field is not None else "").strip()
        if not field or field in seen_fields:
            continue
        seen_fields.add(field)
        if len(out) >= _MAX_BLAST_FIELDS:
            break
        # Verified readers of THIS SPECIFIC field (distinct reader methods), excluding the
        # edit-target's own nodes so it never counts itself. promote.go stores the bare
        # field name in edge.metadata for both READS (promote_field_read) and WRITES
        # (promote_write), so `e.metadata = field` makes the count field-EXACT. Without it
        # the query counted readers of ANY field of the owning class, over-attributing
        # class-wide readers to this one field when the render says "writes to <field>;
        # N verified readers" (a multi-field class would overstate field-level precision).
        # Graph-F6 (B-26 fail-CLOSED): a NULL-confidence READS must not inflate the
        # verified-reader count — COALESCE(...,0.0) fails it below the 0.7 fact floor.
        r_conf = "AND COALESCE(e.confidence, 0.0) >= ?" if has_conf else ""
        r_params: list[object] = [owner_class_id, field]
        if has_conf:
            r_params.append(_BLAST_CONF_FLOOR)
        r_params.extend(node_ids)
        try:
            row = conn.execute(
                f"SELECT COUNT(DISTINCT e.source_id) FROM edges e "
                f"WHERE e.target_id = ? AND e.type = 'READS' AND e.metadata = ? {r_conf} "
                f"AND e.source_id NOT IN ({placeholders})",
                r_params,
            ).fetchone()
        except sqlite3.Error:
            row = None
        n_readers = int(row[0]) if row and row[0] is not None else 0
        if n_readers > 0:
            plural = "reader" if n_readers == 1 else "readers"
            out.append(f"writes to {field}; {n_readers} verified {plural}")
        else:
            out.append(f"writes to {field}")
    return tuple(out)


def _evidence_for(
    conn: sqlite3.Connection,
    file_path: str,
    name: str,
    *,
    is_callee: bool = False,
    ids: list[int] | None = None,
) -> ContractEvidence | None:
    """Build the ContractEvidence for one (file, function), or None if no node.

    ``ids`` may be passed pre-resolved so the caller (build_contract) does not
    run a second identical _node_ids query when it reuses them for callees.
    """
    if ids is None:
        ids = _node_ids(conn, file_path, name)
    if not ids:
        return None
    sig, ret = _node_meta(conn, ids)
    props = _read_props(conn, ids)
    shapes = props.get("return_shape", [])
    return ContractEvidence(
        file=file_path,
        function=name,
        signature=sig,
        return_type=ret,
        raises=tuple(props.get("exception_type", [])),
        guards=tuple(props.get("guard_clause", [])),
        return_shape=shapes[0] if shapes else "",
        boundaries=tuple(props.get("boundary_condition", [])),
        conditionals=tuple(props.get("conditional_return", [])),
        exc_flows=tuple(props.get("exception_flow", [])),
        flows=tuple(props.get("data_flow", [])),
        is_callee=is_callee,
    )


def build_contract(
    graph_db_path: str,
    focus: list[tuple[str, str]],
    *,
    include_callees: bool = True,
    max_callees: int = _MAX_CALLEES,
) -> list[ContractEvidence]:
    """Build the deterministic contract for each (file, function) in ``focus``.

    For each focus function: its own contract (signature + raises + guards + return
    shape, node-local, always-available). When ``include_callees`` and the function
    has VERIFIED 1-hop callees that themselves raise exceptions, append those callee
    contracts (the "what the thing I call can raise" lever) — verified edges only,
    so a name_match callee is never claimed. Pure read; never raises.
    """
    if not focus:
        return []
    conn = _open_ro(graph_db_path)
    if conn is None:
        return []
    try:
        # has_conf gates BOTH the callee edge query AND the G17 blast-fact gate
        # (fires on the inline include_callees=False path too); has_method is
        # callee-only. One cheap PRAGMA either way.
        has_conf, has_method = _has_columns(conn)
        out: list[ContractEvidence] = []
        seen_funcs: set[tuple[str, str]] = set()
        for fpath, fname in focus:
            if not fpath or not fname or (fpath, fname) in seen_funcs:
                continue
            seen_funcs.add((fpath, fname))
            # Resolve node ids ONCE and reuse for both the contract and the
            # callee expansion (was two identical _node_ids queries per focus).
            ids = _node_ids(conn, fpath, fname)
            if not ids:
                continue
            ev = _evidence_for(conn, fpath, fname, ids=ids)
            if ev is None:
                continue
            # G17: attach the edit-target's SCOPE/COMPLETENESS blast facts (its own
            # promoted WRITES + verified-reader counts). Edit-target ONLY — callees
            # below never get blast facts. Display-only; touches no rank/score term.
            blast = _blast_facts(conn, ids, has_conf=has_conf)
            if blast:
                ev = replace(ev, blast=blast)
            out.append(ev)

            if not include_callees:
                continue
            # Verified 1-hop callees that ADD a raise the focus doesn't already
            # surface — the deciding "callee raises X" detail. Verified only.
            callees = _neighbors(
                conn,
                ids,
                direction="callees",
                has_conf=has_conf,
                has_method=has_method,
                max_neighbors=max_callees * 3,
            )
            added = 0
            for edge in callees:
                if added >= max_callees:
                    break
                # Verified-edge gate: never surface a name_match callee as a fact.
                if (edge.resolution_method or "").strip().lower() not in _DETERMINISTIC_METHODS:
                    continue
                if (edge.file, edge.name) in seen_funcs:
                    continue
                # Read the callee contract from the EXACT node the verified edge
                # resolved to (its edges.target_id), so sig AND props come from the
                # SAME node — not sig-over-lowest-line + props-over-the-same-name
                # union (item #17). Abstain if the resolved id can't be recovered.
                callee_id = _resolved_callee_node_id(
                    conn, ids, edge.name, edge.file, has_method=has_method
                )
                if callee_id is None:
                    continue
                cev = _evidence_for(conn, edge.file, edge.name, is_callee=True, ids=[callee_id])
                # Worth showing a callee if it raises/guards OR exposes a
                # signature — the signature is the deciding "call it correctly"
                # interface fact the agent otherwise greps for (Task #48).
                if cev is None or not (cev.raises or cev.guards or cev.signature):
                    continue
                seen_funcs.add((edge.file, edge.name))
                out.append(cev)
                added += 1
        return out
    finally:
        conn.close()


def _fmt_one(ev: ContractEvidence) -> str:
    """Render one function's contract as compact lines (signature first, primacy)."""
    head = f"{ev.file} :: {ev.function}"
    if ev.is_callee:
        head = f"  → calls {ev.function} ({ev.file})"
    lines = [head]
    # Render the signature for BOTH the edit-target AND its verified callees: a
    # callee's signature is the deciding "call it with these args" fact (Task #48).
    if ev.signature:
        lines.append(f"  sig: {ev.signature}")
    if ev.raises:
        lines.append(f"  raises: {', '.join(ev.raises)}")
    if ev.exc_flows:
        lines.append(f"  raises-when: {' | '.join(ev.exc_flows)}")
    if ev.guards:
        lines.append(f"  preserve: {' | '.join(ev.guards)}")
    if ev.boundaries:
        lines.append(f"  bounds: {' | '.join(ev.boundaries)}")
    if ev.flows:
        # def-use: where each input value flows (calls/comparisons/returns it feeds)
        lines.append(f"  flows: {' | '.join(ev.flows)}")
    if ev.blast and not ev.is_callee:
        # G17: SCOPE/COMPLETENESS — the fields this edit-target WRITES + how many
        # other methods READ them (the completeness fact: who else depends on this
        # state). Display-only; never a rank input.
        lines.append(f"  scope: {' | '.join(ev.blast)}")
    if ev.return_shape:
        rt = f" ({ev.return_type})" if ev.return_type else ""
        lines.append(f"  returns: {ev.return_shape}{rt}")
    elif ev.return_type and ev.return_type != "None" and not ev.is_callee:
        lines.append(f"  returns: {ev.return_type}")
    return "\n".join(lines)


def render_contract(items: list[ContractEvidence]) -> str:
    """Render the contract block, or "" when nothing has signal (correct-or-quiet)."""
    blocks = [_fmt_one(ev) for ev in items if ev.has_signal]
    if not blocks:
        return ""
    return "<gt-contract>\n" + "\n".join(blocks) + "\n</gt-contract>"


def contract_line(graph_db_path: str, file_path: str, func_names: list[str]) -> str:
    """Compact single-function inline contract for the per-file brief entry.

    Returns one line like ``raises ValueError,TypeError | preserve not user→raise |
    returns Optional[User]`` for the FIRST function that has any contract signal, or
    "" when none. Used to add a ``Contract:`` line per brief file without the full
    block. No callee expansion (the inline form is the edit-target's own contract).
    """
    if not func_names:
        return ""
    items = build_contract(
        graph_db_path,
        [(file_path, fn) for fn in func_names[:3]],
        include_callees=False,
    )
    for ev in items:
        parts: list[str] = []
        if ev.raises:
            parts.append("raises " + ",".join(ev.raises))
        if ev.guards:
            parts.append("preserve " + "; ".join(ev.guards[:2]))
        if ev.return_shape:
            parts.append("returns " + ev.return_shape)
        elif ev.return_type and ev.return_type != "None":
            parts.append("returns " + ev.return_type)
        if ev.flows:
            # one def-use flow (the edit-target's first param) — compact, single line
            parts.append("flows " + ev.flows[0])
        if ev.blast:
            # G17: one SCOPE/COMPLETENESS blast fact (first written field +
            # verified-reader count) — display-only, never a rank input.
            parts.append("scope " + ev.blast[0])
        if parts:
            return " | ".join(parts)
    return ""


@dataclass(frozen=True)
class CalleeContract:
    """One verified callee of an edit-target function: the signature + location
    the agent must call correctly. Built ONLY from deterministic edges (Task #48).
    """

    caller: str  # the edit-target function name
    callee: str  # the called function/method name
    signature: str  # the callee's full typed signature (the deciding fact)
    file: str  # callee definition file
    line: int  # callee definition start_line (1-based; 0 if unknown)


# NOTE: the legacy ``_node_sig_line(conn, file, name)`` (lowest-line over the
# same-name union) is intentionally GONE — it sourced sig+line from an arbitrary
# overload, not the node the verified edge resolved to (item #17). Callee sig/line
# are now read ONLY by the resolver's actual target id via the two helpers below.
def _node_sig_line_by_id(conn: sqlite3.Connection, node_id: int) -> tuple[str, int]:
    """(signature, start_line) for the EXACT node ``node_id`` the edge resolved to.

    The verified edge already picked a specific target node structurally (type_flow /
    impl_method / import / same_file). Read sig+line from THAT node so an overloaded /
    same-name-across-classes callee never gets the wrong overload's signature/line
    (item #17). Generalized — pure id lookup, any language.
    """
    try:
        row = conn.execute(
            "SELECT signature, start_line FROM nodes WHERE id = ?",
            (node_id,),
        ).fetchone()
    except sqlite3.Error:
        return ("", 0)
    if not row:
        return ("", 0)
    return (_sanitize_signature(str(row[0] or "")), int(row[1]) if row[1] is not None else 0)


def _node_language(conn: sqlite3.Connection, node_id: int | None) -> str:
    """``nodes.language`` for ``node_id``, or '' when unknown/absent/legacy
    schema — '' downstream means 'cannot judge', never 'different' (the
    cross-language disqualifier stays PERMISSIVE on it)."""
    if node_id is None:
        return ""
    try:
        row = conn.execute("SELECT language FROM nodes WHERE id = ?", (node_id,)).fetchone()
    except sqlite3.Error:
        return ""
    return str(row[0]) if row and row[0] else ""


def _resolved_callee_node_id(
    conn: sqlite3.Connection,
    source_ids: list[int],
    callee_name: str,
    callee_file: str,
    *,
    has_method: bool,
) -> int | None:
    """The EXACT target node id the verified CALLS edge resolved to.

    ``_neighbors`` returns only (name, file, confidence, resolution_method) — it
    discards the resolved ``edges.target_id``, so the callee's sig/line/props get
    re-derived by lowest ``start_line`` over the same-name union (an arbitrary
    overload). Recover the resolver's actual target id from the SAME edges join
    ``_neighbors`` used, gated on the SAME verified-method predicate, so sig/line/
    props are read from the node the edge truly points at (item #17).

    Correct-or-quiet: if the verified edge resolved to MULTIPLE distinct target ids
    with this (name, file) — genuinely two overloads both called over verified edges
    — prefer the lowest-line one AMONG ONLY those resolved ids (still pinned to the
    resolver's targets, never the whole file-wide union). Returns None when no
    verified edge to (name, file) exists (then the caller abstains). Generalized:
    pure SQL over edges/nodes, no language- or benchmark-specific logic.
    """
    if not source_ids:
        return None
    placeholders = ",".join("?" for _ in source_ids)
    sql = (
        "SELECT n.id, n.start_line FROM edges e JOIN nodes n ON e.target_id = n.id "
        f"WHERE e.source_id IN ({placeholders}) AND e.type = 'CALLS' "
        "AND n.is_test = 0 AND n.name = ? AND n.file_path = ?"
    )
    params: list[object] = [*source_ids, callee_name, callee_file]
    # Same verified-provenance gate _neighbors applies (only when the column exists);
    # without it the conf=0.0 sentinel path can't prove provenance, so don't filter.
    if has_method:
        _det_in = ",".join("'" + str(m).lower() + "'" for m in sorted(_DETERMINISTIC_METHODS))
        sql += f" AND LOWER(TRIM(e.resolution_method)) IN ({_det_in})"
    try:
        rows = conn.execute(sql, params).fetchall()
    except sqlite3.Error:
        return None
    if not rows:
        return None
    # Pin to the resolver's target id(s); among those, lowest known line wins
    # (NULL line last) for a deterministic, edge-faithful pick.
    rows.sort(key=lambda r: (r[1] is None, r[1] if r[1] is not None else 0))
    return int(rows[0][0])


def edit_target_callee_contracts(
    graph_db_path: str,
    file_path: str,
    func_names: list[str],
    *,
    max_funcs: int = 3,
    max_callees_per_func: int = 3,
) -> list[CalleeContract]:
    """Verified callees (with signatures + locations) of the edit-target functions.

    For each focus function in ``func_names`` (capped), return its 1-hop CALLS
    callees resolved over a VERIFIED edge (resolution_method in same_file / import
    / lsp_verified / …) whose definition node carries a non-empty signature. This
    is the "what does the method I'm editing CALL, and how do I call it" fact — the
    deciding ``set_parse(self, key, string: str)`` the agent otherwise greps for.

    Correct-or-quiet: name_match edges are NEVER included (they would launder a
    guessed call target as fact). Returns [] when nothing verified has a signature.
    Pure read; never raises. Generalized — any file / language indexed by gt-index.
    """
    if not func_names:
        return []
    conn = _open_ro(graph_db_path)
    if conn is None:
        return []
    try:
        has_conf, has_method = _has_columns(conn)
        # Cross-language disqualifier (mini-delivery port, boa [57]): legacy
        # graphs without nodes.language stay PERMISSIVE (no judgement).
        has_lang = _nodes_have_language(conn)
        out: list[CalleeContract] = []
        seen: set[tuple[str, str, str]] = set()  # (caller, callee, file) dedup
        for fname in func_names[:max_funcs]:
            if not fname:
                continue
            ids = _node_ids(conn, file_path, fname)
            if not ids:
                continue
            src_lang = _node_language(conn, ids[0]) if has_lang else ""
            callees = _neighbors(
                conn,
                ids,
                direction="callees",
                has_conf=has_conf,
                has_method=has_method,
                max_neighbors=max_callees_per_func * 3,
            )
            added = 0
            for edge in callees:
                if added >= max_callees_per_func:
                    break
                # Verified-edge gate: never surface a name_match callee as a fact.
                if (edge.resolution_method or "").strip().lower() not in _DETERMINISTIC_METHODS:
                    continue
                # Don't list the function calling itself or a same-name homonym in
                # the same file as a "callee contract" — it adds no interface fact.
                if edge.name == fname and edge.file == file_path:
                    continue
                # Read sig+line from the EXACT node the verified edge resolved to
                # (its edges.target_id), NOT the lowest-line node over the same-name
                # union — else an overload/same-name-method gets the wrong overload's
                # signature+line (item #17). Abstain if the resolved id can't be
                # recovered (correct-or-quiet) rather than emit an arbitrary overload.
                callee_id = _resolved_callee_node_id(
                    conn, ids, edge.name, edge.file, has_method=has_method
                )
                if callee_id is None:
                    continue
                # Cross-language disqualifier: a CALLS edge across language
                # families cannot be a real source-level call — never a
                # callee CONTRACT fact, whatever its deterministic stamp.
                # Permissive when either language is unknown/legacy.
                if has_lang and _is_cross_language_pair(src_lang, _node_language(conn, callee_id)):
                    continue
                sig, line = _node_sig_line_by_id(conn, callee_id)
                if not sig:
                    continue  # correct-or-quiet: no signature, no fact to send
                key = (fname, edge.name, edge.file)
                if key in seen:
                    continue
                seen.add(key)
                out.append(
                    CalleeContract(
                        caller=fname,
                        callee=edge.name,
                        signature=sig,
                        file=edge.file,
                        line=line,
                    )
                )
                added += 1
        return out
    finally:
        conn.close()


def _callee_sig_args(signature: str, _callee: str) -> str:
    """Render a callee signature compactly as ``name(args)``.

    (``_callee`` is retained — positionally — for the call-site contract in
    ``v1r_brief._callee_sig_args(cc.signature, cc.callee)``; it is intentionally unused
    in the body, hence the leading underscore.)

    Strips a leading ``def `` / ``async def `` and any ``-> ReturnType`` tail and a
    trailing colon so the brief shows ``set_parse(self, key, string: str)`` rather
    than ``def set_parse(self, key, string: str) -> None:``. Falls back to the raw
    signature when it does not parse as ``def name(...)``.
    """
    sig = signature.strip()
    is_pydef = False
    for prefix in ("async def ", "def "):
        if sig.startswith(prefix):
            is_pydef = True
            sig = sig[len(prefix) :].strip()
            break
    if not is_pydef:
        # Stage 5 / LIPI 2026-06-10: a non-Python declaration header carries
        # contract AFTER the arg list — return type, throws, generic
        # constraints, and the Rust where-clause (`T: Trace + 'static`, the
        # boa [86] killing fact the parser now preserves). Cutting at the
        # balanced arg list re-introduced exactly the truncation Stage 5
        # fixed; render the full header verbatim.
        return sig.rstrip(":").rstrip()
    # Cut a return annotation / trailing colon after the balanced arg list.
    depth = 0
    end = -1
    for i, ch in enumerate(sig):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                end = i
                break
    if end != -1:
        sig = sig[: end + 1]
    if "(" in sig and sig.endswith(")"):
        return sig
    # Unparseable — return name(args?) best-effort, never a malformed fact.
    return signature.strip().rstrip(":")


# ──────────────────────────────────────────────────────────────────────────
# Contract DRIFT — the NEW capability (not the already-shipped contract context).
#
# After the agent edits a file and GT re-indexes it (gt-index -file), diff the
# edit-target's OWN behavioral contract pre vs post and surface only MATERIAL
# drift: the interface facts a patch broke that the rest of the code depends on
# ("return shape: list -> None; N callers depend on this", "dropped raise:
# KeyError"). This is the deciding "you broke it" signal the agent self-certifies
# away — distinct from re-delivering the contract as context (a proven null).
#
# Keying is by (file, name), NEVER node_id: an incremental reindex is DELETE+
# INSERT so node ids change. Caller counts come from VERIFIED edges only (is_fact
# / _DETERMINISTIC_METHODS), is_test=0 by construction of the call graph — zero
# test contact (the assertions table is never read). Correct-or-quiet: empty
# string when nothing material changed. LLM-free, $0, pure SQL.
# ──────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ContractDrift:
    """Material contract change in one edited function, with caller exposure."""

    file: str
    function: str
    changes: tuple[str, ...]  # rendered change lines
    caller_count: int = 0  # verified (non-test) callers that depend on it
    removed: bool = False  # node gone after reindex (renamed/removed)


def snapshot_contract(graph_db_path: str, file_path: str, func_names: list[str]) -> dict[str, dict]:
    """Capture the edit-target's OWN contract before an edit, JSON-serializable,
    keyed by function name.

    The pre-edit touchpoint persists this (e.g. to /tmp) so ``build_drift`` can
    diff against it after the agent edits + GT re-indexes the file. Own-contract
    only (``include_callees=False``): drift is about what the EDITED function's
    interface became, not its callees'. Pure read; never raises.
    """
    if not func_names:
        return {}
    items = build_contract(
        graph_db_path,
        [(file_path, fn) for fn in func_names],
        include_callees=False,
    )
    snap: dict[str, dict] = {}
    for ev in items:
        snap[ev.function] = {
            "signature": ev.signature,
            "return_type": ev.return_type,
            "return_shape": ev.return_shape,
            "raises": list(ev.raises),
            "guards": list(ev.guards),
        }
    return snap


def _norm_shape(shape: str) -> str:
    """Normalize a return_shape for comparison: keep the category + the structural skeleton (call /
    constructor / method heads, brackets), but BLANK bare variable identifiers. NON-HARM: a local-
    variable rename (`return list(data)` -> `return list(result)`) changes the captured expression
    TEXT but not the contract, and must NOT read as drift — else drift fires noise on every refactor.
    A real structural change (list->dict, .foo()->.bar(), value->None) still differs."""
    if "|" not in shape:
        return shape
    cat, expr = shape.split("|", 1)

    def _repl(m: "re.Match[str]") -> str:
        rest = expr[m.end() :].lstrip()
        return m.group(0) if rest.startswith("(") else "_"  # keep call/constructor/method heads

    return cat + "|" + re.sub(r"[A-Za-z_]\w*", _repl, expr)


def _diff_contract(pre: dict, post: dict) -> list[str]:
    """The material changes pre->post. Order-insensitive for set-valued kinds
    (a reorder is not drift). Correct-or-quiet: only well-formed deltas."""
    changes: list[str] = []
    pre_shape = (pre.get("return_shape") or "").strip()
    post_shape = (post.get("return_shape") or "").strip()
    # Compare STRUCTURE (variable-rename-invariant), not literal text -> no false drift on a rename.
    if _norm_shape(pre_shape) != _norm_shape(post_shape) and (pre_shape or post_shape):
        changes.append(f"return shape: {pre_shape or 'none'} -> {post_shape or 'none'}")
    # LSP-sharpened type-level drift (List[X] -> Optional[X]) when types are known.
    pre_rt = (pre.get("return_type") or "").strip()
    post_rt = (post.get("return_type") or "").strip()
    if pre_rt != post_rt and (pre_rt or post_rt):
        changes.append(f"return type: {pre_rt or 'none'} -> {post_rt or 'none'}")
    pre_raises = set(pre.get("raises") or [])
    post_raises = set(post.get("raises") or [])
    for dropped in sorted(pre_raises - post_raises):
        changes.append(f"dropped raise: {dropped}")
    for added in sorted(post_raises - pre_raises):
        changes.append(f"new raise: {added}")
    pre_guards = set(pre.get("guards") or [])
    post_guards = set(post.get("guards") or [])
    for dropped in sorted(pre_guards - post_guards):
        # CORRECT-OR-QUIET (offline-proof finding, arviz add-guard FP): the indexer captures only a
        # LIMITED set of guard_clauses per function, so ADDING a guard can displace the captured one
        # and look like a "drop". A guard is only really dropped if its exception ALSO disappeared
        # from raises. If the guard's exception is still raised post-edit, this is a capture artifact
        # (not a real drop) -> suppress, so drift never falsely tells the agent it broke a guard.
        _excs = re.findall(r"raise\s+([A-Za-z_][A-Za-z0-9_]*)", dropped)
        if _excs and any(e in post_raises for e in _excs):
            continue
        changes.append(f"dropped guard: {dropped}")
    return changes


def _verified_caller_count(graph_db_path: str, file_path: str, name: str) -> int:
    """Number of VERIFIED (fact) callers of (file, name). name_match callers are
    never counted — a guessed caller must not inflate the consequence.

    Item #14: use the dedicated UNCAPPED ``COUNT(DISTINCT)`` (curation_map.
    verified_caller_count) instead of counting the callers of a
    ``build_function_map(dynamic=False)`` result — that path truncated at
    ``max_neighbors=5``, so a hub with 30 verified callers reported 5 and the
    drift block understated blast radius 6x. A COUNT must never be subject to a
    presentation cap."""
    return verified_caller_count(graph_db_path, file_path, name)


def render_drift(drifts: list[ContractDrift]) -> str:
    """Render the drift block with verification framing folded in, or "" when no
    material drift (correct-or-quiet). Identical payload across scaffolds."""
    if not drifts:
        return ""
    blocks: list[str] = []
    for d in drifts:
        head = f"{d.file} :: {d.function}"
        if d.caller_count > 0:
            s = "s" if d.caller_count != 1 else ""
            head += f"  ({d.caller_count} verified caller{s} depend on this)"
        lines = [head] + [f"  {c}" for c in d.changes]
        blocks.append("\n".join(lines))
    framing = (
        "Your edit changed the behavioral contract below. Confirm each change is "
        "intended - callers depend on the prior contract:"
    )
    return "<gt-drift>\n" + framing + "\n" + "\n".join(blocks) + "\n</gt-drift>"


def build_drift(
    graph_db_path: str,
    file_path: str,
    func_names: list[str],
    *,
    pre_snapshot: dict[str, dict],
) -> str:
    """Diff the post-edit contract (read live from the re-indexed graph) against
    ``pre_snapshot`` and render material drift.

    Call AFTER the agent edits the file AND GT has re-indexed it (so the graph's
    properties reflect the post-edit body). ``pre_snapshot`` is the dict produced
    by ``snapshot_contract`` before the edit. A function present pre but absent
    post = renamed/removed (callers will break). Pure read; never raises; "" when
    nothing material changed.
    """
    if not func_names or not pre_snapshot:
        return ""
    post = snapshot_contract(graph_db_path, file_path, func_names)
    drifts: list[ContractDrift] = []
    for name in func_names:
        pre = pre_snapshot.get(name)
        if pre is None:
            continue  # no baseline for this name -> nothing to diff
        cur = post.get(name)
        if cur is None:
            drifts.append(ContractDrift(file_path, name, ("function removed or renamed",), 0, True))
            continue
        changes = _diff_contract(pre, cur)
        if not changes:
            continue
        cnt = _verified_caller_count(graph_db_path, file_path, name)
        drifts.append(ContractDrift(file_path, name, tuple(changes), cnt))
    return render_drift(drifts)
